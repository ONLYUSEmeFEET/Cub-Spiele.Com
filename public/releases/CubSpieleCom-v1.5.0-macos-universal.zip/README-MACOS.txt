================================================================================
CUB SPIELE.COM — MACOS UNIVERSAL APPLICATION BUNDLE (v1.5.0)
Architecture: Universal (Apple Silicon M1/M2/M3/M4 ARM64 & Intel x86_64)
================================================================================

QUICK START (macOS 11 Big Sur / Monterey / Ventura / Sonoma / Sequoia):
1. Extract this ZIP archive and drag "Cub Spiele.Com.app" to /Applications.
2. Double-click "Cub Spiele.Com.app" to launch.
   (If Gatekeeper prompts on first launch, right-click -> Open, or run:
    xattr -cr "Cub Spiele.Com.app")

NVRAM & HIGH SCORE VAULT LOCATION:
~/Library/Application Support/CubSpieleCom/
================================================================================
