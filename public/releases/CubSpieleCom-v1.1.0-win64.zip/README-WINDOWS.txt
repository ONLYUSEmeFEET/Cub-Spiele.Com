================================================================================
CUB SPIELE.COM — NATIVE WINDOWS x64 STANDALONE EMULATOR (v1.1.0)
================================================================================

QUICK START (WINDOWS 10 / WINDOWS 11 x64):
1. Extract all files from this ZIP archive to any folder on your PC.
2. Double-click "CubSpieleCom.exe" to launch the standalone Windows application.

STANDALONE HANDHELD EMULATOR FEATURES:
- Native Desktop Menu Bar (File, Emulation, Audio/Video, View, Tools)
- Full Retail & Prototype Compatibility (including Castlevania: SotN & Sonic Jam)
- Official RetroAchievements Hardcore Compliance & RA_Integration-x64.dll Toolkit
- Frame Advance (F), Rewind ([), Save State Hit Storage & Offline Unlock Queue
- Screen-Only Mode (2x / 3x / 4x integer scale) & Handheld Console Bezel Mode
- STN Passive-Matrix LCD Ghosting Intensity & Persistence controls
- Streamlined UI by default with optional Advanced Mode (View -> Advanced Mode)
================================================================================
