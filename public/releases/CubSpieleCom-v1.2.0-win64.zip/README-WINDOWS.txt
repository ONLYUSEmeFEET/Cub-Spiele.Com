================================================================================
CUB SPIELE.COM — NATIVE WINDOWS x64 STANDALONE EMULATOR (v1.2.0)
================================================================================

QUICK START (WINDOWS 10 / WINDOWS 11 x64):
1. Extract all files from this ZIP archive to any folder on your PC.
2. Double-click "CubSpieleCom.exe" to launch the standalone Windows application.

STANDALONE HANDHELD EMULATOR FEATURES (mGBA / melonDS DESIGN):
- Native Desktop Menu Bar (File, Emulation, Audio/Video, View, Tools)
- Recently Played ROMs submenu with 1-click Slot 1 / Slot 2 boot
- Screen-Only Mode (2x / 3x / 4x integer scale) & Full Handheld Bezel Mode
- Touch Grid Visibility Slider (0% - 100%)
- Preloaded Slot 1 (Lights Out) & Slot 2 (Sonic Jam) TOSEC ROMs
- Expanded Battery-Backed NVRAM High Score Vault ($FC60-$FEDF)
================================================================================
