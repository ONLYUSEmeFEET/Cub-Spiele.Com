================================================================================
CUB SPIELE.COM — NATIVE WINDOWS x64 STANDALONE EMULATOR (v0.0.1)
================================================================================

QUICK START (WINDOWS 10 / WINDOWS 11 x64):
1. Extract all files from this ZIP archive to any folder on your PC
   (or simply copy "CubSpieleCom.exe" by itself—it is 100% self-contained!).
2. Double-click "CubSpieleCom.exe" to launch the standalone Windows application.

STANDALONE HANDHELD EMULATOR FEATURES:
- Self-Contained Single-File PE32+ Executable with embedded runtime & BIOS
- Native Desktop Menu Bar (File, Emulation, View, Display, Settings, Tools, About)
- Full Retail, Prototype & .zip ROM Support (Load Slot 1/2 & Recent Games)
- Competitive Hardcore Mode, Multi-Player High Score Vault & Online Leaderboards
- Frame Advance (F), Rewind ([), Save States (F5/F8) & Hardware Calendar RTC
- Screen-Only Mode (1x - 8x / Full) & Touch View (Configurable Scale & Compact/Standard/Large Controls)
- Dedicated Display Menu: Screen Color Presets, Custom Colors, LCD Contrast (0% - 100%) & LCD Ghosting (0% - 100%)
- Streamlined UI by default with optional Advanced Mode (Tools -> Advanced Mode)
================================================================================
