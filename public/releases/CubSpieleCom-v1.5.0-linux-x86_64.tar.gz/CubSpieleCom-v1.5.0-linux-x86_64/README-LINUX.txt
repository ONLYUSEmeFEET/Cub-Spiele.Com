================================================================================
CUB SPIELE.COM — LINUX x86_64 & STEAMOS STANDALONE BUILD (v1.5.0)
================================================================================

QUICK START (Ubuntu / Debian / Fedora / Arch / Steam Deck):
1. Extract this archive:
   tar -xzf CubSpieleCom-v1.5.0-linux-x86_64.tar.gz
   cd CubSpieleCom-v1.5.0-linux-x86_64
2. Run the native ELF64 executable or launcher script:
   ./CubSpieleCom
   (or ./CubSpieleCom-Launch.sh)

NVRAM & HIGH SCORE VAULT LOCATION:
~/.config/CubSpieleCom/
================================================================================
