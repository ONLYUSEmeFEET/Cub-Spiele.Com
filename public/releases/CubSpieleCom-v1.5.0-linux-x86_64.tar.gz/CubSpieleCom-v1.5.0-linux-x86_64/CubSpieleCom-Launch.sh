#!/bin/sh
# Cub Spiele.Com — Linux x86_64 / SteamOS Standalone Host
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_HTML="$SCRIPT_DIR/app/index.html"
CONFIG_BASE="${XDG_CONFIG_HOME:-$HOME/.config}/CubSpieleCom"
mkdir -p "$CONFIG_BASE/Profile"

for BIN in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge brave-browser; do
  if command -v "$BIN" >/dev/null 2>&1; then
    exec "$BIN" \
      --app="file://$APP_HTML" \
      --window-size=920,760 \
      --allow-file-access-from-files \
      --autoplay-policy=no-user-gesture-required \
      --user-data-dir="$CONFIG_BASE/Profile" >/dev/null 2>&1 &
    exit 0
  fi
done

exec xdg-open "$APP_HTML" >/dev/null 2>&1 &
