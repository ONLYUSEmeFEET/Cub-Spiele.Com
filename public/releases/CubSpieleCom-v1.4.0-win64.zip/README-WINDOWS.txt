================================================================================
CUB SPIELE.COM — NATIVE WINDOWS x64 STANDALONE EMULATOR (v1.4.0)
================================================================================

QUICK START (WINDOWS 10 / WINDOWS 11 x64):
1. Extract all files from this ZIP archive to any folder on your PC.
2. Double-click "CubSpieleCom.exe" to launch the standalone Windows application.

STANDALONE HANDHELD EMULATOR FEATURES:
- Native Desktop Menu Bar (File, Emulation, Audio/Video, View, Tools)
- Recently Played ROMs submenu with TigerDMGC cartridge header verification
- Screen-Only Mode (2x / 3x / 4x integer scale) & Handheld Console Bezel Mode
- STN Passive-Matrix LCD Ghosting Intensity & Persistence controls
- 2-Shade LCD Color Blender
- Internal Real-Time Clock & Date synced to your device
================================================================================
